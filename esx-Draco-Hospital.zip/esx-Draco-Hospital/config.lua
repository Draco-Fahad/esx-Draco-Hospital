Config = {}

Config.EnableBlips = false
Config.EnablePeds = true

Config.DoctorLimit = false
Config.maxDoctor = 0
Config.doctorPrice = 5000
Config.Doctor = {
    {x = 328.74, y = -577.41, z = 43.32, heading = 168.56, type = 'legal'}
}