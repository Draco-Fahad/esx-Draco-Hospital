fx_version "adamant"
game "gta5"
Author "Draco#7539"

description 'Draco-Customs'

client_scripts {
    'client/client.lua',
    'config.lua'
}

server_scripts {
    'server/server.lua',
    'config.lua'
}